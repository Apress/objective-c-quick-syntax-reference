//
//  Project.m
//  978-1-4302-6487-3_Ch16_source_code
//
//  Created by Matthew Campbell on 10/29/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import "Project.h"

@interface Project()

@property(strong) NSArray *listOfTasks;

-(void)generateAnotherReport;

@end

@implementation Project

-(void)generateReport{
    NSLog(@"This is a report!");
    self.makeCustomReport(@"Custom Project Report Title");
}

-(void)generateReportAndAddThisString:(NSString *)string
                   andThenAddThisDate:(NSDate *)date{
    [self generateReport];
    NSLog(@"%@", string);
    NSLog(@"Date: %@", date);
}

-(void)generateAnotherReport{
    NSLog(@"Another report!");

}

+(void)printTimeStamp{
    NSLog(@"Timestamp: %@", [NSDate date]);
}

-(id)init{
    self = [super init];
    if (self) {
        log1 = @"log1";
    }
    return self;
}

@end