//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Project.h"

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        //How to use a block
        float (^squareThis)(float);
        
        squareThis = ^(float x){
            return x * x;
        };
        
        float result = squareThis(4);
        
        NSLog(@"result = %f", result);
        
        NSString *title = @"Multiply Block Execution";
        
        float (^multiplyThese)(float, float) = ^(float x, float y){
            NSLog(title);
            
            return x * y;
        };
        
        NSLog(@"multiplyThese(3,4) = %f", multiplyThese(3,4));
        
        Project *p =[[Project alloc]init];
        p.makeCustomReport = ^(NSString* title){
            NSLog(@"%@", title);
            NSLog(@"This is a custom report requested by the author");
            NSLog(@"Say This");
            NSLog(@"Say That");
            NSLog(@"Say The Other Thing");
        };
        [p generateReport];
        
        return 0;
    }
}