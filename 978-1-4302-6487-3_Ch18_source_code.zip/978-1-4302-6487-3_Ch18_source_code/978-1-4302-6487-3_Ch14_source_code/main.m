//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SpecialProject.h"

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        Project *p = [[Project alloc] init];
        [p generateReport];
        
        [Project printTimeStamp];
        
        SpecialProject *sp = [[SpecialProject alloc]init];
        
        NSString *tempLog = sp->log3;
        
        NSLog(@"temp = %@", tempLog);
        
        return 0;
    }
}