//
//  main.m
//  978-1-4302-6487-3_Ch01_source_code
//
//  Created by Matthew Campbell on 9/11/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        NSLog(@"NSInteger is %lu bytes", sizeof(NSInteger));
        NSLog(@"NSUInteger is %lu bytes", sizeof(NSUInteger));
        NSLog(@"BOOL is %lu bytes", sizeof(BOOL));
        NSLog(@"CGFloat is %lu bytes", sizeof(CGFloat));
        
        //{
            NSInteger numberOfPeople;
            numberOfPeople = 100;
        //}
        NSLog(@"The number of people is %li", numberOfPeople);
        
        NSInteger numberOfGroups = 20;
        NSLog(@"The number of groups is %li", numberOfGroups);
        
        NSUInteger num_unsigned = 200;
        NSLog(@"num_unsigned is %lu", num_unsigned);
        NSLog(@"NSUIntegerMax is %lu", NSUIntegerMax);
        
        NSInteger num_signed = -200;
        NSLog(@"num_signed is %li", num_signed);
        NSLog(@"NSIntegerMin is %li", NSIntegerMin);
        NSLog(@"NSIntegerMax is %li", NSIntegerMax);
        
        BOOL success = NO;
        
        NSLog(@"success is %i", success);
        NSLog(@"success: %@", success ? @"YES" : @"NO");
        
        CGFloat percent = 33.34;
        NSLog(@"percent is %f", percent);
        NSLog(@"DBL_MAX is %f", DBL_MAX);
        
    }
    return 0;
}