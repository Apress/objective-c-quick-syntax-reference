//
//  AppDelegate.h
//  iPhone_NSUInteger_Test
//
//  Created by Matthew Campbell on 9/20/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
