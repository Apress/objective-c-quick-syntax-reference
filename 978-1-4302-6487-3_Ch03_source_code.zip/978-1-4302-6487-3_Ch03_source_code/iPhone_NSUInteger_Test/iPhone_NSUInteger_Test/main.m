//
//  main.m
//  iPhone_NSUInteger_Test
//
//  Created by Matthew Campbell on 9/20/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        
        NSUInteger num_unsigned = 200;
        NSLog(@"num_unsigned is %lu", num_unsigned);
        NSLog(@"NSUIntegerMax is %lu", NSUIntegerMax);
        
        NSInteger num_signed = -200;
        NSLog(@"num_signed is %li", num_signed);
        NSLog(@"NSIntegerMin is %li", NSIntegerMin);
        NSLog(@"NSIntegerMax is %li", NSIntegerMax);
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
