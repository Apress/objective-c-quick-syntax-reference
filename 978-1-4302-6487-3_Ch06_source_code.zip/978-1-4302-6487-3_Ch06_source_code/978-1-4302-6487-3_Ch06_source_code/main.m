//
//  main.m
//  978-1-4302-6487-3_Ch06_source_code
//
//  Created by Matthew Campbell on 9/24/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        NSLog(@"Hello, World!");
        
        NSString *firstName = @"Matthew";
        NSString *lastName = @"Campbell";
        
        NSString *name = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
        NSLog(@"name = %@", name);
        
        NSString *fileName = @"/Users/Shared/studyreport.txt";
        
        NSString *fileContents = [NSString stringWithContentsOfFile:fileName
                                                           encoding:NSStringEncodingConversionAllowLossy
                                                              error:nil];
        
        NSLog(@"fileContents = %@", fileContents);
        
        NSMutableString *alpha = [NSMutableString stringWithString:@"A"];
        [alpha insertString:@"B"
                    atIndex:[alpha length]];
        [alpha appendString:@"C"];
        NSLog(@"alpha = %@", alpha);
        
        NSRange range;
        range.location = 1;
        range.length = 1;
        [alpha deleteCharactersInRange:range];
        NSLog(@"alpha = %@", alpha);
        
        range.location = 0;
        range.length = 2;
        
        [alpha replaceOccurrencesOfString:@"AC"
                               withString:@"ABCDEFGHI"
                                  options:NSLiteralSearch
                                    range:range];
        NSLog(@"alpha = %@", alpha);
        
    }
    return 0;
}