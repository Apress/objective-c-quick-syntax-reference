//
//  main.m
//  978-1-4302-6487-3_Ch13_source_code
//
//  Created by Matthew Campbell on 10/4/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        /*NSArray *numbers = @[@-2, @-1, @0, @1, @2];
        
        for (NSNumber *num in numbers){
            NSLog(@"num ^ 2= %f", [num floatValue] * [num floatValue]);
        }*/
        
        NSDictionary *d1 = @{@"one": @1, @"two": @2, @"three": @3};
        for (id object in d1){
            NSLog(@"object = %@", object);
        }
        
        for (id object in d1){
            NSNumber *num = [d1 objectForKey:object];
            NSLog(@"num = %@", num);
        }
        
    }
    return 0;
}