//
//  main.m
//  978-1-4302-6487-3_Ch10_source_code
//
//  Created by Matthew Campbell on 10/1/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
    
        for (int i=0; i<10; i++) {
            NSLog(@"i = %i", i);
        }
        
        NSArray *list = @[@-2.0, @-1.0, @0.0, @1.0, @2.0];
        NSMutableString *report = [[NSMutableString alloc] init];
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        
        for (int i=0; i<list.count; i++) {
            NSNumber *num = [list objectAtIndex:i];
            NSString *spelledOutNum = [formatter stringFromNumber:num];
            [report appendString:spelledOutNum];
            [report appendString:@", "];
        }
        
        NSLog(@"report = %@", report);
        
    }
    return 0;
}