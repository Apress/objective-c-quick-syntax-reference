//
//  main.m
//  978-1-4302-6487-3_Ch29_source_code
//
//  Created by Matthew Campbell on 11/15/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool{
        
        NSString *APILogin = @"mattjdrake";
        NSString *APIKey = @"R_8face63d8f3c9827d0f2162502a18a07";
        NSString *longURL = @"https://mobileappmastery.com";
        NSString *requestString = [NSString stringWithFormat:@"http://api.bit.ly/shorten?version=2.0.1&longUrl=%@&login=%@&apiKey=%@&format=json", longURL, APILogin, APIKey];
        
        NSURL *requestURL = [NSURL URLWithString:requestString];
        NSURLSession *session = [NSURLSession sharedSession];
        
        [[session dataTaskWithURL:requestURL
                completionHandler:^(NSData *data,
                                    NSURLResponse *response,
                                    NSError *error) {
                    
                    NSError *e = nil;
                    NSDictionary *bitlyJSON = [NSJSONSerialization JSONObjectWithData:data
                                                                              options:0
                                                                                error:&e];
                    
                    if(!error){
                        NSDictionary *results = [bitlyJSON objectForKey:@"results"];
                        NSDictionary *resultsForLongURL = [results objectForKey:longURL];
                        NSString *shortURL = [resultsForLongURL objectForKey:@"shortUrl"];
                        NSLog(@"shortURL = %@", shortURL);
                    }
                    else
                        NSLog(@"There was an error parsing the JSON");
                    
                }] resume];
        
        sleep(60);
        
    }
    
    return 0;
}