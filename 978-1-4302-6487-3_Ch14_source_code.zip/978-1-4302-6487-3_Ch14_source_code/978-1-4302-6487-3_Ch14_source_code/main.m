//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        //Typical If Statement
        if(1 < 2){
            NSLog(@"That is true");
        }
        else{
            NSLog(@"Not true");
        }
        
        //Nested If Statement
        if(1 > 2){
            NSLog(@"True");
        }
        else{
            if(3 > 4){
                NSLog(@"True");
            }
            else{
                NSLog(@"Not True");
            }
        }
        
        //If Statement With Variable
        BOOL isTrue = 1 == 2;
        
        if(isTrue){
            NSLog(@"isTrue = %@", isTrue ? @"YES" : @"NO");
            NSLog(@"That was a true statement.");
        }
        else{
            NSLog(@"isTrue = %@", isTrue ? @"YES" : @"NO");
            NSLog(@"That was not a true statement.");
        }
        
    }
    return 0;
}