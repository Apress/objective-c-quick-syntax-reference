//
//  Task.h
//  978-1-4302-6487-3_Ch21_source_code
//
//  Created by Matthew Campbell on 11/7/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Task : NSObject<NSCoding>

@property(strong) NSString *name;
@property(assign) BOOL done;

-(void)generateReport;

@end