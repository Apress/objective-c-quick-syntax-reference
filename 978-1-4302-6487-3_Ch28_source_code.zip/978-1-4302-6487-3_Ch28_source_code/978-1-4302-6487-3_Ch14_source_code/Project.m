//
//  Project.m
//  978-1-4302-6487-3_Ch16_source_code
//
//  Created by Matthew Campbell on 10/29/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import "Project.h"

@implementation Project

-(void)generateReport{
    NSLog(@"Report for %@ Project", self.name);
    [self.listOfTasks enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [obj generateReport];
    }];
}

-(void)encodeWithCoder:(NSCoder *)encoder {
    [encoder encodeObject:self.name forKey:@"namekey"];
    [encoder encodeObject:self.listOfTasks forKey:@"listOfTaskskey"];
}

-(id)initWithCoder:(NSCoder *)decoder {
    self = [super init];
    if (self) {
        self.name = [decoder decodeObjectForKey:@"namekey"];
        self.listOfTasks = [decoder decodeObjectForKey:@"listOfTaskskey"];
    }
    return self;
}

@end