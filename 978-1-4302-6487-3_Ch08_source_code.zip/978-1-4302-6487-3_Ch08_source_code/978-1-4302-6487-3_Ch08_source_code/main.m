//
//  main.m
//  978-1-4302-6487-3_Ch08_source_code
//
//  Created by Matthew Campbell on 9/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){

    @autoreleasepool {
        NSArray *numbers = @[@-2, @-1, @0, @1, @2];
        NSArray *letters = @[@"A", @"B", @"C", @"D", @"E", @"F"];
        
        NSLog(@"numbers = %@", numbers);
        NSLog(@"letters = %@", letters);
        
        NSNumber *num = [numbers objectAtIndex:1];
        NSLog(@"num = %@", num);
        
        NSNumber *lastNum = [numbers lastObject];
        NSLog(@"lastNum = %@", lastNum);
        
        NSUInteger index = [numbers indexOfObject:num];
        NSLog(@"index = %li", index);
        
        [numbers enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            NSLog(@"obj ^ 2= %f", [obj floatValue] * [obj floatValue]);
        }];
        
        NSMutableArray *mArray = [NSMutableArray arrayWithArray:@[@-2, @-1, @0]];
        NSLog(@"mArray = %@", mArray);
        
        [mArray addObject:@1];
        [mArray removeObject:@1];
        
        NSLog(@"mArray = %@", mArray);
        [mArray exchangeObjectAtIndex:0 withObjectAtIndex:1];
        NSLog(@"mArray = %@", mArray);
        
    }
    return 0;
}