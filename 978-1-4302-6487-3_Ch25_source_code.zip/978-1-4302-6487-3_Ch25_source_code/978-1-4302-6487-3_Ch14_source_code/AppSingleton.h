//
//  AppSingleton.h
//  978-1-4302-6487-3_Ch25_source_code
//
//  Created by Matthew Campbell on 11/12/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppSingleton : NSObject

+ (AppSingleton *)sharedInstance;

@end