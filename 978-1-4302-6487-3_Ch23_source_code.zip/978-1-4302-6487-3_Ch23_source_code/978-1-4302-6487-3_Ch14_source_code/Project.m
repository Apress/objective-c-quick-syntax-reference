//
//  Project.m
//  978-1-4302-6487-3_Ch16_source_code
//
//  Created by Matthew Campbell on 10/29/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import "Project.h"

@implementation Project

-(void)generateReport{
    NSLog(@"Report for %@ Project", self.name);
    [self.listOfTasks enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [obj generateReport];
    }];
}

-(void)observeValueForKeyPath:(NSString *)keyPath
                     ofObject:(id)object
                       change:(NSDictionary *)change
                      context:(void *)context{
    
    if([keyPath isEqualToString:@"done"]){
        NSNumber *updatedStatus = [change objectForKey:@"new"];
        BOOL done = [updatedStatus boolValue];
        NSLog(@"Task '%@' is now %@", [object name], done ? @"DONE" : @"IN PROGRESS");
    }
}

-(void)dealloc{
    [self.listOfTasks enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [obj removeObserver:self
                 forKeyPath:@"done"];
    }];
}

-(void)thisTask:(Task *)task statusHasChangedToThis:(BOOL)done{
    NSLog(@"Task '%@' is now %@", task.name, done ? @"DONE" : @"IN PROGRESS");
}

@end