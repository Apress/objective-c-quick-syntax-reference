//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Project.h"

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        Project *p = [[Project alloc]init];
        p.listOfTasks = [[NSMutableArray alloc]init];
        p.name = @"Cook Dinner";
        
        Task *t1 = [[Task alloc]init];
        t1.name = @"Choose Menu";
        [p.listOfTasks addObject:t1];
        
        Task *t2 = [[Task alloc]init];
        t2.name = @"Buy Groceries";
        [p.listOfTasks addObject:t2];
        
        Task *t3 = [[Task alloc]init];
        t3.name = @"Prepare Ingredients";
        [p.listOfTasks addObject:t3];
        
        Task *t4 = [[Task alloc]init];
        t4.name = @"Cook Food";
        [p.listOfTasks addObject:t4];
        
        [p.listOfTasks enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            [obj addObserver:p
                  forKeyPath:@"done"
                     options:NSKeyValueObservingOptionNew
                     context:nil];
        }];
        
        
        t4.done  = YES;
        t4.done  = NO;
        t2.done = YES;
        t1.done = NO;
        
        return 0;
    }
}