//
//  SpecialProject.h
//  978-1-4302-6487-3_Ch18_source_code
//
//  Created by Matthew Campbell on 10/31/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import "Project.h"

@interface SpecialProject : Project

-(void)generateSpecialReport;
-(void)generateReport;

@end