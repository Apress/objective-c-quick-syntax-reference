//
//  main.m
//  978-1-4302-6487-3_Ch04_source_code
//
//  Created by Matthew Campbell on 9/23/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        1 + 2 - 3 * 4 / 5;
        
        NSLog(@"1.0 + 2.0 - 3.0 * 4.0 / 5.0 = %f", 1.0 + 2.0 - 3.0 * 4.0 / 5.0);
        
        CGFloat t1 = 1.0 + 2.0 - 3.0 * 4.0 / 5.0;
        NSLog(@"t1 = %f", t1);
        
        NSLog(@"Result 1 = %f", 1.0 + 2.0 - 3.0 * 4.0 / 5.0);   // 0.600000
        NSLog(@"Result 2 = %f", 1.0 + (2.0 - 3.0 * 4.0) / 5.0); // -1.000000
        NSLog(@"Result 3 = %f", (1.0 + 2.0 - 3.0 * 4.0) / 5.0); // -1.800000
        
        NSUInteger t2 = 100;
        NSLog(@"t2 = %lu", t2);
        NSUInteger t3 = 10 * 10;
        NSLog(@"t3 = %lu", t3);
        
        t2++;
        t2 = t2 + 1;
        
        BOOL t4 = 5 < 4;
        NSLog(@"t4 = %@", t4 ? @"YES" : @"NO"); // NO
        
        BOOL t5 = YES && NO;  // NO
        BOOL t6 = YES && YES; // YES
        BOOL t7 = YES || NO;  // YES
        BOOL t8 = NO || NO;   // NO
        BOOL t9 = !YES;       // NO
        
        NSLog(@"t9 = %@", t9 ? @"YES" : @"NO"); // YES
        
        
        
        
    }
    return 0;
}