//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        NSOperationQueue *background = [[NSOperationQueue alloc] init];
        [background addOperationWithBlock:^{
            for (int i1=20000; i1>0; i1--) {
                NSLog(@"i1 = %i", i1);
            }
        }];
        /*[background addOperationWithBlock:^{
            for (int i2=0; i2<=30000; i2++) {
                NSLog(@"i2 = %i", i2);
            }
        }];
        [background addOperationWithBlock:^{
            for (int i3=0; i3<=40000; i3++) {
                NSLog(@"i3 = %i", i3);
            }
        }];*/
        
        for (int y=0; y<=10000; y++) {
            NSLog(@"y = %i", y);
        }
        
        return 0;
    }
}