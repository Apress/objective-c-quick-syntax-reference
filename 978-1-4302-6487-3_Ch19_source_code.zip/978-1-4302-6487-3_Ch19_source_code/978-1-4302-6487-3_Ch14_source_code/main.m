//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Project.h"

@interface Project(ProjectExtension)

-(id)initWithName:(NSString *)aName;

@end

@implementation Project (ProjectExtension)

-(id)initWithName:(NSString *)aName{
    self = [super init];
    if (self) {
        self.name = aName;
    }
    
    return self;
}

@end

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        Project *p = [[Project alloc] initWithName:@"ThisNewProject"];
        NSLog(@"p.name = %@", p.name);
        
        return 0;
    }
}