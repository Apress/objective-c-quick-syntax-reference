//
//  Project.h
//  978-1-4302-6487-3_Ch16_source_code
//
//  Created by Matthew Campbell on 10/29/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Project : NSObject{
    @private NSString *log1;
    @protected NSString *log2;
    @public NSString *log3;
}

@property(strong) NSString *name;

-(void)generateReport;
-(void)generateReportAndAddThisString:(NSString *)string
                   andThenAddThisDate:(NSDate *)date;
+(void)printTimeStamp;

@end