//
//  SpecialProject.m
//  978-1-4302-6487-3_Ch18_source_code
//
//  Created by Matthew Campbell on 10/31/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import "SpecialProject.h"

@implementation SpecialProject

-(void)generateSpecialReport{
    NSLog(@"This is a special report!");
}

-(void)generateReport{
    [super generateReport];
    [self generateSpecialReport];
}

-(id)init{
    self = [super init];
    if (self) {
        log2 = @"log2";
        log3 = @"log3";
    }
    return self;
}

@end