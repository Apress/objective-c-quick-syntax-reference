//
//  main.m
//  978-1-4302-6487-3_Ch11_source_code
//
//  Created by Matthew Campbell on 10/2/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
    
        /*int i = 0;
        
        while (i < 10) {
            NSLog(@"i = %i", i);
            i++;
        }*/
        
        NSArray *list = @[@-2.0, @-1.0, @0.0, @1.0, @2.0];
        NSMutableString *report = [[NSMutableString alloc] init];
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        
        int i = 0;
        
        while(i < list.count) {
            NSNumber *num = [list objectAtIndex:i];
            NSString *spelledOutNum = [formatter stringFromNumber:num];
            [report appendString:spelledOutNum];
            [report appendString:@", "];
            i++;
        }
        
        NSLog(@"report = %@", report);
        
    }
    return 0;
}