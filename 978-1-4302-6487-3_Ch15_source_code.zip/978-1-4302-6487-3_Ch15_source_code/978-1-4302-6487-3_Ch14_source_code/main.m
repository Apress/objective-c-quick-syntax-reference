//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        NSInteger shape = 0;
        
        float area;
        
        switch (shape) {
                
            case 0:{
                float length = 3;
                area = length * length;
                NSLog(@"Square area is %f", area);
                break;
            }
            case 1:{
                float base = 16;
                float height = 24;
                area = base * height;
                NSLog(@"Parallelogram area is %f", area);
                break;
            } default:{
                area = -999;
                NSLog(@"No Shape Specified");
                break;
            }
                
        }
        return 0;
    }
}