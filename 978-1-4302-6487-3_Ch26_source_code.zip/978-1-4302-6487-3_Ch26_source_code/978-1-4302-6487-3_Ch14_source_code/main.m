//
//  main.m
//  978-1-4302-6487-3_Ch14_source_code
//
//  Created by Matthew Campbell on 10/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        NSError *error = nil;
        
        NSString *file = @"/Users/Shared/array.txt";
        
        NSString *content = [NSString stringWithContentsOfFile:file
                                                     encoding:NSStringEncodingConversionAllowLossy
                                                        error:&error];
        if(!error)
            NSLog(@"content = %@", content);
        else
            NSLog(@"error = %@", error);
        
        
        NSArray *array = [NSArray arrayWithContentsOfFile:file];
        
        @try {
            NSString *fifthItem = [array objectAtIndex:4];
            NSLog(@"fifthItem = %@", fifthItem);
        }
        @catch (NSException *exception) {
            NSLog(@"exception = %@", exception);
        }
        @finally {
            NSLog(@"Moving on...");
        }
        
        return 0;
    }
}