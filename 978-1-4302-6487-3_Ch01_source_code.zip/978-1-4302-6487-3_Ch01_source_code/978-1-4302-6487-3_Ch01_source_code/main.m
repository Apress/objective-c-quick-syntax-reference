    //
//  main.m
//  978-1-4302-6487-3_Ch01_source_code
//
//  Created by Matthew Campbell on 9/11/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        
    }
    return 0;
}

