//
//  main.m
//  978-1-4302-6487-3_Ch05_source_code
//
//  Created by Matthew Campbell on 9/23/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        NSObject *object;
        object = [[NSObject alloc] init];
        NSLog(@"object = %@", object);
        
        NSURL *url = [[NSURL alloc] initWithString:@"https://mobileappmastery.com"];
        NSLog(@"website = %@", url);
        
        NSDate *today = [NSDate date];
        NSLog(@"today = %@", today);
        
        NSObject *object2 = [NSObject new];
        NSLog(@"object = %@", object2);
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        [fileManager removeItemAtPath:@"/Users/Shared/studyreport.txt"
                                error:nil];
        
    }
    return 0;
}