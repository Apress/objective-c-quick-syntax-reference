//
//  Task.m
//  978-1-4302-6487-3_Ch21_source_code
//
//  Created by Matthew Campbell on 11/7/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import "Task.h"

@implementation Task

-(void)generateReport{
    NSLog(@"Task %@ is %@", self.name, self.done ? @"DONE" : @"IN PROGRESS");
}

BOOL _done;

-(void)setDone:(BOOL)done{
    _done = done;
    [self.delegate thisTask:self statusHasChangedToThis:done];
}

-(BOOL)done{
    return _done;
}

@end