//
//  Project.h
//  978-1-4302-6487-3_Ch16_source_code
//
//  Created by Matthew Campbell on 10/29/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Task.h"

@interface Project : NSObject<TaskDelegate>

@property(strong) NSString *name;
@property(strong) NSMutableArray *listOfTasks;

-(void)generateReport;

@end