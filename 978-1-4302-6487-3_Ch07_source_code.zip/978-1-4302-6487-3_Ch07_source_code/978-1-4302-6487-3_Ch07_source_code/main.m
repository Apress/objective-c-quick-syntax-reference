//
//  main.m
//  978-1-4302-6487-3_Ch07_source_code
//
//  Created by Matthew Campbell on 9/25/13.
//  Copyright (c) 2013 Mobile App Mastery. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]){
    @autoreleasepool {
        
        NSNumber *num1 = @1;
        NSNumber *num2 = @2.25;
        NSLog(@"num1 = %@, num2 = %@", num1, num2);
        
        NSNumber *num3 = [NSNumber numberWithInteger:3];
        NSNumber *num4 = [NSNumber numberWithFloat:4.44];
        
        NSLog(@"num3 = %@, num4 = %@", num3, num4);
        
        CGFloat result = [num1 floatValue] + [num2 floatValue];
        NSLog(@"result = %f", result);
        
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterCurrencyStyle;
        NSLog(@"Formatted num2 = %@", [formatter stringFromNumber:num2]);
        
        //NSString *number = @"two point two five";
        formatter.numberStyle = NSNumberFormatterSpellOutStyle;
        NSNumber *num5 = [formatter numberFromString:@"two point two five"];
        NSLog(@"num5 = %@", num5);
        
    }
    return 0;
}